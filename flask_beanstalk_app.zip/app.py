from flask import Flask

application = Flask(__name__)

@application.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Flask on AWS Elastic Beanstalk</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                background: linear-gradient(135deg, #e0f7fa, #fce4ec);
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                text-align: center;
                padding-top: 5%;
            }
            .card {
                max-width: 600px;
                margin: auto;
                padding: 30px;
                border-radius: 15px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                background-color: white;
            }
            h1 {
                color: #0077b6;
                font-weight: bold;
            }
            p {
                color: #555;
                font-size: 1.1rem;
            }
            a {
                margin-top: 15px;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>🌍 Flask App on AWS Elastic Beanstalk</h1>
            <p class="mt-3">
                Congratulations! 🎉 Your Flask web application is successfully running on 
                <b>Amazon Web Services</b> using <b>Elastic Beanstalk</b>.
            </p>
            <hr>
            <p>
                This app is built with <b>Python + Flask</b> and deployed effortlessly using 
                AWS’s powerful deployment automation tools.
            </p>
            <a href="https://aws.amazon.com/elasticbeanstalk/" target="_blank" class="btn btn-primary">
                Learn More About Elastic Beanstalk
            </a>
        </div>
    </body>
    </html>
    '''

@application.route('/about')
def about():
    return '''
    <h2 style="text-align:center; color:darkgreen; margin-top:50px;">
        🌱 About This Flask Application
    </h2>
    <p style="text-align:center; font-size:18px; color:#444;">
        This simple Flask app demonstrates how easily you can deploy a Python web application 
        on AWS Elastic Beanstalk — no complex setup needed!
    </p>
    <div style="text-align:center; margin-top:20px;">
        <a href="/" style="text-decoration:none; color:#0077b6;">⬅ Back Home</a>
    </div>
    '''

if __name__ == '__main__':
    application.run(host='0.0.0.0', port=5000)
